D-DAY AMIGA BUILD (v 4.1)

This is an officially unsupported version of D-Day: Normandy.

The D-Day: Normandy Amiga version was ported by Steffen Haeuser to work with the Amiga port of Quake2 (also done by Steffen Haeuser & others at Hyperion Entertainment). This Amiga version was based off of the previous Linux port of D-Day and as such all the issues with the linux build also apply to the Amiga version. Be sure to check out readme.linux.txt for more information concerning these issues. Any Amiga port related questions may be directed to SteffenH@hyperion-entertainment.com.

As of this release, the Quake 2 version for Amiga has not yet been publicly released. Please check the following website:
		
	http://www.hyperion-entertainment.com.

The makefiles, dll sources, and other necessary directives have been included to compile correctly.

D-Day: Normandy is only a modification to Quake 2. As such, it is limited to the actual executable, and the Amiga port is no exception: an Amiga with PowerPC CPU is required using a PPC Board from Phase 5 or DCE running OS 3.x with the WarpUP PPC Kernel or using the soon-to-be-released AmigaOne PPC Hardware. Quake 2 for Amiga and the D-Day: Normandy modification will also run on upcoming OS 4.0 for PPC Hardware. 

Here are the minimum specs for the soon-to-be-released Quake 2 port on AmigaOS:

PowerPC 603e 150 MHz
64 MB RAM
WarpUP PPC Kernel or AmigaOS 4.0 (4.0 is still in works)
A Zorro or PCI based Graphics Board (3D Hardware recommended, but not required)

Good Luck!
